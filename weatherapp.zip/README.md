# Weather App

A beautiful and interactive weather application that provides real-time weather information, including temperature, humidity, wind speed, and local time for any location worldwide.

## Features

- Search for any city or country
- Real-time weather information
- Dynamic background based on time of day
- Weather-specific sound effects
- Responsive design
- Animated weather icons

## Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/weather-app.git
```

2. Open `index.html` in your browser

## Project Structure

```
weather-app/
├── assets/
│   ├── images/
│   │   ├── clear.png
│   │   ├── cloud.png
│   │   ├── mist.png
│   │   ├── rain.png
│   │   ├── snow.png
│   │   └── 404.png
│   └── sounds/
│       ├── sunny.mp3
│       ├── rain.mp3
│       ├── snow1.mp3
│       ├── cloud1.mp3
│       ├── haze1.mp3
│       ├── 1.mp3
│       └── loading.mp3
├── css/
│   └── style.css
├── js/
│   └── app.js
├── index.html
├── README.md
└── .gitignore
```

## APIs Used

- OpenWeatherMap API
- REST Countries API
- TimezoneDB API

## Note

Remember to replace the API keys in the code with your own:
- OpenWeatherMap API key
- TimezoneDB API key